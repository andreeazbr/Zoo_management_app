package db;

import java.sql.*;

public class JavaBean {
	String url = "jdbc:mysql://localhost:3306/gradina_zoologica?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
	String user = "root";
	String password = "oparoladeneuitat";
	Connection con = null;

	public void connect() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection(url, user, password);
	}

	public void disconnect() throws SQLException {
		if (con != null)
			con.close();
	}

	public ResultSet vedeTabela(String tabel) throws SQLException {
		Statement stmt = con.createStatement();
		return stmt.executeQuery("SELECT * FROM " + tabel + ";");
	}

	public ResultSet vedeEvaluari() throws SQLException {
		Statement stmt = con.createStatement();
		String sql = "SELECT e.id_evaluare, a.id_animal, a.nume, a.specie, "
				+ "c.id_caracteristica, c.nume_caracteristica, c.unitate_masura, "
				+ "e.valoare_masurata, e.data_evaluare, e.observatii " + "FROM evaluari_caracteristici e "
				+ "JOIN animale a ON e.id_animal = a.id_animal "
				+ "JOIN caracteristici c ON e.id_caracteristica = c.id_caracteristica;";
		return stmt.executeQuery(sql);
	}

	public ResultSet intoarceLinieDupaId(String tabela, String numeColoanaId, int id) throws SQLException {
		Statement stmt = con.createStatement();
		String sql = "SELECT * FROM " + tabela + " WHERE " + numeColoanaId + " = " + id + ";";
		return stmt.executeQuery(sql);
	}

	public void adaugaAnimal(String nume, String specie, int varsta, String data) throws SQLException {
		String sql = "INSERT INTO animale (nume, specie, varsta, data_inregistrare) VALUES (?, ?, ?, ?);";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, nume);
		pstmt.setString(2, specie);
		pstmt.setInt(3, varsta);
		pstmt.setString(4, data);
		pstmt.executeUpdate();
		pstmt.close();
	}

	public void adaugaCaracteristica(String nume, String unitate) throws SQLException {
		String sql = "INSERT INTO caracteristici (nume_caracteristica, unitate_masura) VALUES (?, ?);";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, nume);
		pstmt.setString(2, unitate);
		pstmt.executeUpdate();
		pstmt.close();
	}

	public void adaugaEvaluare(int idA, int idC, String val, String data, String obs) throws SQLException {
		String sql = "INSERT INTO evaluari_caracteristici (id_animal, id_caracteristica, valoare_masurata, data_evaluare, observatii) VALUES (?, ?, ?, ?, ?);";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, idA);
		pstmt.setInt(2, idC);
		pstmt.setString(3, val);
		pstmt.setString(4, data);
		pstmt.setString(5, obs);
		pstmt.executeUpdate();
		pstmt.close();
	}

	public void modificaTabela(String tabela, String primaryKey, int id, String[] campuri, String[] valori)
			throws SQLException {
		StringBuilder update = new StringBuilder("UPDATE " + tabela + " SET ");
		for (int i = 0; i < campuri.length; i++) {
			update.append(campuri[i]).append(" = '").append(valori[i]).append("'");
			if (i < campuri.length - 1)
				update.append(", ");
		}
		update.append(" WHERE ").append(primaryKey).append(" = ").append(id).append(";");

		Statement stmt = con.createStatement();
		stmt.executeUpdate(update.toString());
		stmt.close();
	}

	public void stergeDateTabela(String[] ids, String tabela, String numeId) throws SQLException {
		if (ids != null) {
			Statement stmt = con.createStatement();
			for (String id : ids) {
				stmt.executeUpdate("DELETE FROM " + tabela + " WHERE " + numeId + " = " + id + ";");
			}
			stmt.close();
		}
	}

}