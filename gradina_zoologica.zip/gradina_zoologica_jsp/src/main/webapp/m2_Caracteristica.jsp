<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Confirmare Modificare Caracteristică</title>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
            </div>
        </nav>

        <div class="container mt-5 text-center">
            <%
                try {
                    jb.connect();
                    
                    // 1. Preluăm datele din m1_Caracteristica.jsp
                    int id = Integer.parseInt(request.getParameter("id_caracteristica"));
                    String nume = request.getParameter("nume_caracteristica");
                    String unitate = request.getParameter("unitate_masura");

                    // 2. Pregătim coloanele și valorile pentru SQL
                    String[] campuri = {"nume_caracteristica", "unitate_masura"};
                    String[] valori = {nume, unitate};
                    
                    // 3. Apelăm metoda de modificare generică
                    jb.modificaTabela("caracteristici", "id_caracteristica", id, campuri, valori);
                    jb.disconnect();
            %>
            
            <div class="card shadow-sm mx-auto" style="max-width: 500px;">
                <div class="card-body p-5">
                    <div class="text-success mb-4">
						<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="#198754" class="bi bi-check-circle-fill" viewBox="0 0 16 16" version="1.1">
  							<path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
						</svg>
                    </div>
                    <h2 class="card-title">Modificare Reușită!</h2>
                    <p class="card-text">Caracteristica <strong><%= nume %></strong> a fost actualizată în nomenclator.</p>
                    <hr>
                    <a href="tabela_Caracteristici.jsp" class="btn btn-custom px-4">Înapoi la Tabelă</a>
                </div>
            </div>

            <%
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger shadow-sm p-4'>");
                    out.println("<h4>Eroare la procesare</h4>");
                    out.println("<p>" + e.getMessage() + "</p>");
                    out.println("<a href='tabela_Caracteristici.jsp' class='btn btn-danger mt-3'>Înapoi</a></div>");
                }
            %>
        </div>
    </body>
</html>