<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,db.*,java.sql.*"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Administrare Caracteristici</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .nav-custom { background-color: #36486b !important; }
        .btn-custom { background-color: #36486b; color: white; }
    </style>
</head>
<jsp:useBean id="jb" scope="session" class="db.JavaBean" />
<body>
<nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navAnimale" role="button" data-bs-toggle="dropdown" style="color:white;">Animale</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Animale.jsp">Vizualizează Inventar</a></li> 
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Animal.jsp">Editează Date</a></li>
                            </ul>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navCarac" role="button" data-bs-toggle="dropdown" style="color:white;">Caracteristici</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Caracteristici.jsp">Vizualizează Tipuri</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Caracteristica.jsp">Editează Tipuri</a></li>
                            </ul>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navEval" role="button" data-bs-toggle="dropdown" style="color:white;">Evaluări Medicale</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Evaluari.jsp">Jurnal Evaluări</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Evaluare.jsp">Editează Jurnal</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>

    <div class="container mt-4">
        <h1 class="text-center">Modificare Tipuri Caracteristici</h1>
        <br/>
        <form action="m1_Caracteristica.jsp" method="post">
            <table class="table table-bordered table-hover text-center shadow-sm">
                <thead class="table-dark">
                    <tr>
                        <th>Selectează</th>
                        <th>ID</th>
                        <th>Denumire Caracteristică</th>
                        <th>Unitate de Măsură</th>
                    </tr>
                </thead>
                <tbody>
                <%
                    try {
                        jb.connect();
                        ResultSet rs = jb.vedeTabela("caracteristici");
                        while (rs.next()) {
                            int id = rs.getInt("id_caracteristica");
                %>
                    <tr>
                        <td><input type="radio" name="primarykey" value="<%= id %>" required /></td>
                        <td><%= id %></td>
                        <td><%= rs.getString("nume_caracteristica") %></td>
                        <td><%= rs.getString("unitate_masura") %></td>
                    </tr>
                <%
                        }
                        rs.close();
                    } catch (Exception e) {
                        out.print("<tr><td colspan='4'>Eroare: " + e.getMessage() + "</td></tr>");
                    } finally {
                        jb.disconnect();
                    }
                %>
                </tbody>
            </table>
            <div class="text-center mt-4">
                <button type="submit" class="btn btn-custom px-5">Editează Caracteristica</button>
            </div>
        </form>
    </div>
</body>
</html>