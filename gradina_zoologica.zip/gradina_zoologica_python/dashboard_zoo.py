import customtkinter as ctk
import mysql.connector
import matplotlib.pyplot as plt
from fpdf import FPDF
from tkinter import messagebox
from PIL import Image
import csv

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class ZooDashboard(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Zoo Analytics Pro v2.0")
        self.geometry("1100x650")

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.sidebar_frame = ctk.CTkFrame(self, width=220, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, sticky="nsew")

        imagine_logo = ctk.CTkImage(light_image=Image.open("Zoo.png"),
                                    dark_image=Image.open("Zoo.png"),
                                    size=(100, 100))

        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="", image=imagine_logo)
        self.logo_label.pack(pady=20)

        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="🦁\nZOO PRO",
                                       font=ctk.CTkFont(size=32, weight="bold"),
                                       text_color=("#36486b", "#ffffff"))
        self.logo_label.pack(pady=(30, 10))

        self.btn_home = ctk.CTkButton(self.sidebar_frame, text="🏠 Acasă",
                                      fg_color="transparent", text_color=("#1a1a1a", "#ffffff"),
                                      hover_color="#3498db", anchor="w", command=self.show_home)
        self.btn_home.pack(fill="x", padx=20, pady=(10, 10))

        self.btn_mgmt = ctk.CTkButton(self.sidebar_frame, text="🦁 Management",
                                      fg_color="transparent", text_color=("#1a1a1a", "#ffffff"),
                                      hover_color="#3498db", anchor="w", command=self.show_mgmt)
        self.btn_mgmt.pack(fill="x", padx=20, pady=10)

        self.btn_lista = ctk.CTkButton(self.sidebar_frame, text="📋 Listă Completă",
                                       fg_color="transparent", text_color=("#1a1a1a", "#ffffff"),
                                       hover_color="#16a085", anchor="w", command=self.show_lista_animale)
        self.btn_lista.pack(fill="x", padx=20, pady=10)

        self.btn_stats = ctk.CTkButton(self.sidebar_frame, text="📊 Statistici",
                                       fg_color="transparent", text_color=("#1a1a1a", "#ffffff"),
                                       hover_color="#e67e22", anchor="w", command=self.show_stats)
        self.btn_stats.pack(fill="x", padx=20, pady=10)

        self.btn_reports = ctk.CTkButton(self.sidebar_frame, text="📄 Rapoarte PDF",
                                         fg_color="transparent", text_color=("#1a1a1a", "#ffffff"),
                                         hover_color="#9b59b6", anchor="w", command=self.show_reports)
        self.btn_reports.pack(fill="x", padx=20, pady=10)

        self.btn_about = ctk.CTkButton(self.sidebar_frame, text="ℹ️Despre Proiect",
                                       fg_color="transparent", text_color=("#1a1a1a", "#ffffff"),
                                       hover_color="#95a5a6", anchor="w", command=self.show_about)
        self.btn_about.pack(fill="x", padx=20, pady=10)

        self.appearance_mode_label = ctk.CTkLabel(self.sidebar_frame, text="Temă Interfață:",
                                                  text_color=("#1a1a1a", "#ffffff"), anchor="w")
        self.appearance_mode_optionemenu = ctk.CTkOptionMenu(self.sidebar_frame, values=["Dark", "Light"],
                                                             command=self.change_appearance_mode)
        self.appearance_mode_optionemenu.pack(side="bottom", padx=20, pady=(0, 10))

        self.appearance_mode_label.pack(side="bottom", padx=20, pady=(0, 20))

        self.main_frame = ctk.CTkFrame(self, corner_radius=20, fg_color="transparent")
        self.main_frame.grid(row=0, column=1, padx=30, pady=30, sticky="nsew")

        self.show_home()

    def clear_main_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def change_appearance_mode(self, new_appearance_mode: str):
        ctk.set_appearance_mode(new_appearance_mode)

    def create_stat_card(self, parent, titlu, valoare, culoare):
        card = ctk.CTkFrame(parent, width=220, height=120, corner_radius=15, border_width=2, border_color=culoare)
        card.grid_propagate(False)

        label_titlu = ctk.CTkLabel(card, text=titlu, font=("Roboto", 14, "bold"))
        label_titlu.pack(pady=(15, 5))

        label_valoare = ctk.CTkLabel(card, text=str(valoare), font=("Roboto", 32, "bold"), text_color=culoare)
        label_valoare.pack(pady=5)
        return card

    def show_home(self):
        self.clear_main_frame()

        ctk.CTkLabel(self.main_frame, text="🐾 Bine ai venit la Zoo Admin Pro!",
                     font=("Roboto", 32, "bold"), text_color=("#2c3e50", "#ecf0f1")).pack(pady=(30, 10))

        ctk.CTkLabel(self.main_frame, text="O privire de ansamblu asupra bazei de date:",
                     font=("Roboto", 16)).pack(pady=(0, 30))

        stats_container = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        stats_container.pack(pady=10)

        try:
            db = self.get_db_connection()
            cursor = db.cursor()

            cursor.execute("SELECT COUNT(*) FROM animale")
            nr_animale = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(DISTINCT specie) FROM animale")
            nr_specii = cursor.fetchone()[0]

            cursor.execute("SELECT nume, varsta FROM animale ORDER BY varsta DESC LIMIT 1")
            oldest = cursor.fetchone()
            oldest_text = f"{oldest[1]} ani" if oldest else "N/A"

            self.create_stat_card(stats_container, "Total Animale", nr_animale, "#3498db").grid(row=0, column=0,
                                                                                                padx=15)
            self.create_stat_card(stats_container, "Specii", nr_specii, "#2ecc71").grid(row=0, column=1, padx=15)
            self.create_stat_card(stats_container, "Vârsta Max", oldest_text, "#e67e22").grid(row=0, column=2, padx=15)

            status_text = f"Sistemul este conectat la baza de date. Sunt {nr_animale} animale înregistrate."
            ctk.CTkLabel(self.main_frame, text=status_text, font=("Roboto", 12, "italic"), text_color="gray").pack(
                side="bottom", pady=20)
            db.close()
        except Exception as e:
            ctk.CTkLabel(self.main_frame, text=f"Eroare la încărcarea datelor: {e}", text_color="red").pack()

        try:
            img_data = Image.open("Zoo.png")
            img_home = ctk.CTkImage(light_image=img_data, dark_image=img_data, size=(150, 150))
            img_label = ctk.CTkLabel(self.main_frame, text="", image=img_home)
            img_label.pack(pady=40)
        except:
            pass
        ctk.CTkLabel(self.main_frame, text="⚠️ Alerte Atenție Medicală",
                     font=("Roboto", 18, "bold"), text_color="#e74c3c").pack(pady=(20, 10))

        alert_box = ctk.CTkTextbox(self.main_frame, width=700, height=150, border_width=2, border_color="#e74c3c")
        alert_box.pack(pady=10)

        try:
            db = self.get_db_connection()
            cursor = db.cursor()

            query_alerte = """
                    SELECT nume, specie FROM animale a
                    WHERE NOT EXISTS (
                        SELECT 1 FROM evaluari_caracteristici ec 
                        WHERE ec.id_animal = a.id_animal 
                        AND ec.data_evaluare > DATE_SUB(NOW(), INTERVAL 6 MONTH)
                    )
                """
            cursor.execute(query_alerte)
            animale_uitate = cursor.fetchall()

            if animale_uitate:
                alert_box.insert("0.0", "Următoarele animale necesită un control medical urgent:\n\n")
                for a in animale_uitate:
                    alert_box.insert("end", f"• {a[0]} ({a[1]}) - Nicio evaluare recentă!\n")
            else:
                alert_box.insert("0.0", "✅ Toate animalele au controalele la zi.")

            alert_box.configure(state="disabled")
            db.close()
        except Exception as e:
            alert_box.insert("0.0", f"Eroare la verificarea alertelor: {e}")

    def show_mgmt(self):
        self.clear_main_frame()
        ctk.CTkLabel(self.main_frame, text="🦁 Gestiune Animale", font=("Roboto", 28, "bold"),
                     text_color=("#2c3e50", "#ecf0f1")).pack(pady=20)

        self.entry_nume = ctk.CTkEntry(self.main_frame, placeholder_text="Introdu numele animalului...",
                                       width=400, height=40)
        self.entry_nume.pack(pady=20)

        btn_container = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        btn_container.pack(pady=10)

        ctk.CTkButton(btn_container, text="Adaugă Nou", fg_color="#2ecc71",
                      command=self.deschide_fereastra_adaugare).pack(side="left", padx=10)
        ctk.CTkButton(btn_container, text="Modifică", fg_color="#f39c12", command=self.deschide_fereastra_editare).pack(
            side="left", padx=10)
        ctk.CTkButton(btn_container, text="Șterge", fg_color="#e74c3c", command=self.sterge_animal).pack(side="left",
                                                                                                         padx=10)

    def show_stats(self):
        self.clear_main_frame()
        ctk.CTkLabel(self.main_frame, text="📈 Analytics & Grafice", font=("Roboto", 28, "bold"),
                     text_color=("#2c3e50", "#ecf0f1")).pack(pady=20)

        grid_btns = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        grid_btns.pack(expand=True)

        ctk.CTkButton(grid_btns, text="🦒 Specii\n(Grafic Bare)", width=250, height=150,
                      fg_color="#3498db", font=("Roboto", 18, "bold"), command=self.afiseaza_specii).grid(row=0,
                                                                                                          column=0,
                                                                                                          padx=20,
                                                                                                          pady=20)

        ctk.CTkButton(grid_btns, text="🐢 Top Vârstă\n(Clasament)", width=250, height=150,
                      fg_color="#e67e22", font=("Roboto", 18, "bold"), command=self.afiseaza_top_varsta).grid(row=0,
                                                                                                              column=1,
                                                                                                              padx=20,
                                                                                                              pady=20)

        ctk.CTkButton(grid_btns, text="⚖️ Evoluție Greutate\n(Analiză Nume)", width=540, height=100,
                      fg_color="#16a085", font=("Roboto", 18, "bold"), command=self.afiseaza_greutate).grid(row=1,
                                                                                                            column=0,
                                                                                                            columnspan=2,
                                                                                                            pady=10)

    def show_reports(self):
        self.clear_main_frame()
        ctk.CTkLabel(self.main_frame, text="📄 Generator Rapoarte PDF", font=("Roboto", 28, "bold"),
                     text_color=("#2c3e50", "#ecf0f1")).pack(pady=20)

        self.entry_pdf = ctk.CTkEntry(self.main_frame, placeholder_text="Nume animal pentru export...", width=400,
                                      height=40)
        self.entry_pdf.pack(pady=20)

        ctk.CTkButton(self.main_frame, text="Exportă Fișă Medicală (.pdf)", fg_color="#9b59b6",
                      width=300, height=50, font=("Roboto", 14, "bold"), command=self.genereaza_pdf).pack(pady=10)

    def get_db_connection(self):
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="oparoladeneuitat",
            database="gradina_zoologica"
        )

    def afiseaza_specii(self):
        try:
            db = self.get_db_connection()
            cursor = db.cursor()
            cursor.execute("SELECT specie, COUNT(*) FROM animale GROUP BY specie")
            date = cursor.fetchall()

            specii = [row[0] for row in date]
            numar = [row[1] for row in date]

            plt.figure("Distribuție Specii")
            plt.bar(specii, numar, color='skyblue')
            plt.show()
            db.close()
        except Exception as e:
            messagebox.showinfo("Eroare!",f"Eroare: {e}")

    def afiseaza_top_varsta(self):
        try:
            db = self.get_db_connection()
            cursor = db.cursor()
            cursor.execute("SELECT nume, varsta, specie FROM animale ORDER BY varsta DESC LIMIT 5")
            date = cursor.fetchall()

            if not date:
                messagebox.showinfo("Info", "Nu există date în baza de date.")
                return

            nume_etichete = [f"{row[0]} ({row[2]})" for row in date]
            varste = [row[1] for row in date]

            nume_etichete.reverse()
            varste.reverse()

            plt.figure("Top 5 Vârstă Exactă", figsize=(10, 6))
            bars = plt.barh(nume_etichete, varste, color='#e67e22')

            for bar in bars:
                width = bar.get_width()
                plt.text(width + 0.3,
                         bar.get_y() + bar.get_height() / 2,
                         f'{int(width)} ani',
                         va='center',
                         fontweight='bold',
                         color=("black" if ctk.get_appearance_mode() == "Light" else "black"))

            plt.title("Top 5 Cele Mai Bătrâne Animale", fontsize=14, pad=20)
            plt.xlabel("Vârstă (Ani)")
            plt.tight_layout()
            plt.show()

            db.close()
        except Exception as e:
            messagebox.showerror("Eroare", f"Nu s-a putut genera graficul: {e}")

    def afiseaza_greutate(self):
        dialog = ctk.CTkInputDialog(text="Introdu numele animalului:", title="Analiză Greutate")
        nume_animal = dialog.get_input()

        if not nume_animal:
            return

        try:
            db = self.get_db_connection()
            cursor = db.cursor()
            query = """
                SELECT ec.data_evaluare, ec.valoare_masurata 
                FROM evaluari_caracteristici ec
                JOIN animale a ON ec.id_animal = a.id_animal
                JOIN caracteristici c ON ec.id_caracteristica = c.id_caracteristica
                WHERE a.nume = %s AND c.nume_caracteristica LIKE 'Greutate%'
                ORDER BY ec.data_evaluare ASC
            """
            cursor.execute(query, (nume_animal,))
            date = cursor.fetchall()
            if date:
                zile = [row[0].strftime("%d-%m") for row in date]
                valori = [float(row[1]) for row in date]

                plt.figure(f"Evoluție Greutate: {nume_animal}", figsize=(10, 5))
                plt.plot(zile, valori, marker='o', linestyle='-', color='#16a085')
                plt.title(f"Evoluția Greutății - {nume_animal}")
                plt.grid(True, alpha=0.3)
                plt.show()
            else:
                messagebox.showinfo("Informație", f"Nu s-au găsit date de greutate pentru '{nume_animal}'.")
            db.close()
        except Exception as e:
            messagebox.showerror("Eroare DB", f"A apărut o eroare: {e}")

    def deschide_fereastra_adaugare(self):
        # Creăm o fereastră nouă (Pop-up)
        self.win_adaugare = ctk.CTkToplevel(self)
        self.win_adaugare.title("Adăugare Animal")
        self.win_adaugare.geometry("400x500")
        self.win_adaugare.attributes('-topmost', True)

        ctk.CTkLabel(self.win_adaugare, text="Adaugă un animal nou", font=("Roboto", 20)).pack(pady=20)

        entry_nume = ctk.CTkEntry(self.win_adaugare, placeholder_text="Nume", width=200)
        entry_nume.pack(pady=10)

        entry_specie = ctk.CTkEntry(self.win_adaugare, placeholder_text="Specie", width=200)
        entry_specie.pack(pady=10)

        entry_varsta = ctk.CTkEntry(self.win_adaugare, placeholder_text="Vârstă", width=200)
        entry_varsta.pack(pady=10)

        def salveaza():
            n = entry_nume.get()
            s = entry_specie.get()
            v = entry_varsta.get()

            if not v.isdigit():
                messagebox.showinfo("Eroare!", "Vârsta trebuie să fie un număr!")
                return

            if n and s and v:
                try:
                    db = self.get_db_connection()
                    cursor = db.cursor()
                    sql = "INSERT INTO animale (nume, specie, varsta, data_inregistrare) VALUES (%s, %s, %s, CURDATE())"
                    cursor.execute(sql, (n, s, v))
                    db.commit()

                    messagebox.showinfo("Succes!",f"Succes! {n} a fost adăugat.")
                    db.close()
                    self.win_adaugare.destroy()
                except Exception as e:
                    messagebox.showinfo("Eroare!",f"Eroare la salvare: {e}")
            else:
                messagebox.showinfo("Eroare!","Toate câmpurile sunt obligatorii!")

        ctk.CTkButton(self.win_adaugare, text="Salvează în DB", command=salveaza).pack(pady=20)

    def sterge_animal(self):
        nume_animal = self.entry_nume.get()
        if not nume_animal:
            messagebox.showinfo("Eroare!","Introdu numele animalului pentru a-l șterge!")
            return

        try:
            db = self.get_db_connection()
            cursor = db.cursor()
            sql = "DELETE FROM animale WHERE nume = %s"
            cursor.execute(sql, (nume_animal,))
            db.commit()

            if cursor.rowcount > 0:
                messagebox.showinfo("Succes!",f"Animalul {nume_animal} a fost șters.")
            else:
                messagebox.showinfo("Eroare!","Animalul nu a fost găsit.")
            db.close()
        except Exception as e:
            messagebox.showinfo("Eroare!",f"Eroare la ștergere!")

    def deschide_fereastra_editare(self):
        nume_cautat = self.entry_nume.get()
        if not nume_cautat:
            messagebox.showinfo("Eroare!","Introdu numele animalului în căsuța de text pentru a-l edita!")
            return

        try:
            db = self.get_db_connection()
            cursor = db.cursor()
            cursor.execute("SELECT nume, specie, varsta FROM animale WHERE nume = %s", (nume_cautat,))
            date = cursor.fetchone()

            if date:
                self.win_edit = ctk.CTkToplevel(self)
                self.win_edit.title(f"Editare {nume_cautat}")
                self.win_edit.geometry("400x400")
                self.win_edit.attributes('-topmost', True)

                e_nume = ctk.CTkEntry(self.win_edit, width=200)
                e_nume.insert(0, date[0])
                e_nume.pack(pady=10)

                e_specie = ctk.CTkEntry(self.win_edit, width=200)
                e_specie.insert(0, date[1])
                e_specie.pack(pady=10)

                e_varsta = ctk.CTkEntry(self.win_edit, width=200)
                e_varsta.insert(0, str(date[2]))
                e_varsta.pack(pady=10)

                def update_db():
                    try:
                        cursor.execute("""
                            UPDATE animale 
                            SET nume=%s, specie=%s, varsta=%s 
                            WHERE nume=%s
                        """, (e_nume.get(), e_specie.get(), e_varsta.get(), nume_cautat))
                        db.commit()
                        messagebox.showinfo("Succes!","Date actualizate cu succes!")
                        self.win_edit.destroy()
                        db.close()
                    except Exception as ex:
                        messagebox.showinfo("Eroare!",f"Eroare la update: {ex}")

                ctk.CTkButton(self.win_edit, text="Salvează Modificările", command=update_db).pack(pady=20)
            else:
                messagebox.showinfo("Eroare!","Animalul nu a fost găsit!")
                db.close()
        except Exception as e:
            messagebox.showinfo("Eroare!",f"Eroare: {e}")

    def genereaza_pdf(self):
        nume_animal = self.entry_pdf.get() if hasattr(self, 'entry_pdf') else self.entry_nume.get()

        try:
            db = self.get_db_connection()
            cursor = db.cursor()

            cursor.execute("SELECT id_animal, nume, specie, varsta FROM animale WHERE nume = %s", (nume_animal,))
            animal = cursor.fetchone()

            if animal:
                id_an = animal[0]
                pdf = FPDF()
                pdf.add_page()

                try:
                    pdf.image('Zoo.png', 10, 8, 30)
                except Exception as img_err:
                    print(f"Imaginea nu a putut fi incarcata: {img_err}")

                pdf.set_font("Arial", 'B', 18)
                pdf.ln(10)
                pdf.cell(190, 10, txt=f"FISA MEDICALA COMPLETA: {nume_animal.upper()}", ln=True, align='C')


                pdf.set_draw_color(52, 152, 219)
                pdf.line(10, 35, 200, 35)
                pdf.ln(15)

                pdf.set_font("Arial", 'B', 12)
                pdf.cell(190, 10, txt="Date Identificare:", ln=True)
                pdf.set_font("Arial", size=11)
                pdf.cell(190, 7, txt=f"Specie: {animal[2]}", ln=True)
                pdf.cell(190, 7, txt=f"Varsta: {animal[3]} ani", ln=True)
                pdf.ln(10)

                query_eval = """
                    SELECT ec.data_evaluare, c.nume_caracteristica, ec.valoare_masurata, c.unitate_masura
                    FROM evaluari_caracteristici ec
                    JOIN caracteristici c ON ec.id_caracteristica = c.id_caracteristica
                    WHERE ec.id_animal = %s
                    ORDER BY ec.data_evaluare DESC
                """
                cursor.execute(query_eval, (id_an,))
                evaluari = cursor.fetchall()

                pdf.set_font("Arial", 'B', 12)
                pdf.cell(190, 10, txt="Istoric Masuratori Medicale:", ln=True)

                # Cap de tabel
                pdf.set_fill_color(200, 200, 200)
                pdf.set_font("Arial", 'B', 10)
                pdf.cell(40, 8, "Data", 1, 0, 'C', True)
                pdf.cell(60, 8, "Caracteristica", 1, 0, 'C', True)
                pdf.cell(40, 8, "Valoare", 1, 0, 'C', True)
                pdf.cell(50, 8, "Unitate", 1, 1, 'C', True)

                pdf.set_font("Arial", size=10)
                for ev in evaluari:
                    pdf.cell(40, 8, str(ev[0]), 1)
                    pdf.cell(60, 8, str(ev[1]), 1)
                    pdf.cell(40, 8, str(ev[2]), 1)
                    pdf.cell(50, 8, str(ev[3]), 1, 1)

                nume_fisier = f"Fisa_Medicala_{nume_animal}.pdf"
                pdf.output(nume_fisier)
                messagebox.showinfo("Succes!", f"Raportul complet pentru {nume_animal} a fost generat.")
            else:
                messagebox.showinfo("Eroare!", "Animalul nu a fost găsit.")

            db.close()
        except Exception as e:
            messagebox.showinfo("Eroare!", f"Eroare PDF: {e}")

    def show_lista_animale(self):
        self.clear_main_frame()

        ctk.CTkLabel(self.main_frame, text="📋 Inventar Complet Animale", font=("Roboto", 28, "bold"),
                     text_color=("#2c3e50", "#ecf0f1")).pack(pady=(20, 10))

        filter_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        filter_frame.pack(pady=10, padx=20, fill="x")

        ctk.CTkLabel(filter_frame, text="Caută (Nume/Specie):", font=("Roboto", 14)).pack(side="left", padx=10)

        self.entry_cautare = ctk.CTkEntry(filter_frame, placeholder_text="Tastează pentru a filtra...", width=300)
        self.entry_cautare.pack(side="left", padx=10)

        self.entry_cautare.bind("<KeyRelease>", lambda event: self.update_tabel_filtrat())

        btn_refresh = ctk.CTkButton(filter_frame, text="🔄 Refresh", width=100,
                                    fg_color="#16a085", command=self.show_lista_animale)
        btn_refresh.pack(side="right", padx=10)

        btn_csv = ctk.CTkButton(filter_frame, text="📊 Export CSV", width=100,
                                fg_color="#2980b9", command=self.exporta_inventar_csv)
        btn_csv.pack(side="right", padx=10)

        self.scroll_frame_lista = ctk.CTkScrollableFrame(self.main_frame, width=850, height=400)
        self.scroll_frame_lista.pack(pady=10, padx=20, fill="both", expand=True)

        self.update_tabel_filtrat()

    def update_tabel_filtrat(self):
        for widget in self.scroll_frame_lista.winfo_children():
            widget.destroy()
        termen_cautat = self.entry_cautare.get().lower()

        try:
            db = self.get_db_connection()
            cursor = db.cursor()
            query = "SELECT id_animal, nume, specie, varsta, data_inregistrare FROM animale"
            cursor.execute(query)
            rows = cursor.fetchall()

            header_text = f"{'ID':<6} | {'Nume':<18} | {'Specie':<18} | {'Vârstă':<10} | {'Data Inreg.':<15}\n"
            header_text += "=" * 80 + "\n"

            txt_display = ctk.CTkTextbox(self.scroll_frame_lista, font=("Courier New", 15), width=800, height=400)
            txt_display.pack(fill="both", expand=True)
            txt_display.insert("0.0", header_text)

            for animal in rows:
                if termen_cautat in animal[1].lower() or termen_cautat in animal[2].lower():
                    data_str = str(animal[4]) if animal[4] else "N/A"
                    line = f"{animal[0]:<6} | {animal[1]:<18} | {animal[2]:<18} | {animal[3]:<10} | {data_str:<15}\n"
                    txt_display.insert("end", line)

            txt_display.configure(state="disabled")
            db.close()
        except Exception as e:
            print(f"Eroare filtrare: {e}")

    def exporta_inventar_csv(self):
        try:
            db = self.get_db_connection()
            cursor = db.cursor()
            cursor.execute("SELECT id_animal, nume, specie, varsta, data_inregistrare FROM animale")
            date = cursor.fetchall()

            nume_fisier = "Inventar_Zoo.csv"
            with open(nume_fisier, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(['ID', 'Nume', 'Specie', 'Varsta', 'Data Inregistrare'])
                writer.writerows(date)

            messagebox.showinfo("Succes", f"Inventarul a fost exportat cu succes în '{nume_fisier}'!")
            db.close()
        except Exception as e:
            messagebox.showerror("Eroare", f"Nu s-a putut exporta: {e}")

    def show_about(self):
        """Afișează o fereastră cu informații despre autor și tehnologii"""
        messagebox.showinfo("Despre Proiect",
                            "🐾 Sistem Gestiune Zoo Pro v2.0\n\n"
                            "Autor: Andreea Zbranca\n"
                            "Disciplina: Programarea interfețelor pentru baze de date\n\n"
                            "Tehnologii utilizate:\n"
                            "• Python & CustomTkinter (Interfață)\n"
                            "• MySQL (Baza de date)\n"
                            "• Matplotlib (Analiză grafică)\n"
                            "• FPDF (Generare rapoarte)")


if __name__ == "__main__":
    app = ZooDashboard()
    app.mainloop()