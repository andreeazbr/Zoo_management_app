<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Status Ștergere Animal</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
            </div>
        </nav>

        <div class="container mt-5 text-center">
        <%
            String[] selectate = request.getParameterValues("primarykey");
            
            if (selectate != null && selectate.length > 0) {
                try {
                    jb.connect();
                    jb.stergeDateTabela(selectate, "animale", "id_animal");
                    jb.disconnect();
        %>
            <div class="alert alert-success shadow-sm p-5">
                <h1 class="display-4">Operațiune Reușită!</h1>
                <p class="lead">Animalele selectate (și evaluările lor asociate) au fost eliminate din sistem.</p>
                <hr>
                <div class="mt-4">
                    <a href="tabela_Animale.jsp" class="btn btn-custom btn-lg px-5">Înapoi la Inventar</a>
                </div>
            </div>
        <%
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger p-4'>");
                    out.println("<h2>Eroare la ștergere!</h2>");
                    out.println("<p>Mesaj: " + e.getMessage() + "</p>");
                    out.println("<a href='tabela_Animale.jsp' class='btn btn-danger mt-3'>Înapoi</a></div>");
                }
            } else {
        %>
            <div class="alert alert-warning shadow-sm p-5">
                <h1>Nicio selecție făcută!</h1>
                <p>Vă rugăm să marcați cel puțin un animal din listă pentru a-l putea șterge.</p>
                <a href="tabela_Animale.jsp" class="btn btn-warning mt-3">Înapoi la Inventar</a>
            </div>
        <%
            }
        %>
        </div>
    </body>
</html>