<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,db.*,java.sql.*"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Adaugă Caracteristică Nouă</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .nav-custom { background-color: #36486b !important; }
        .btn-custom { background-color: #36486b; color: white; }
    </style>
</head>
<jsp:useBean id="jb" scope="session" class="db.JavaBean" />
<body>
    <nav class="navbar navbar-dark nav-custom px-3">
        <a class="navbar-brand" href="index.jsp">Zoo Admin</a>
    </nav>

    <div class="container mt-5">
        <%
            String numeC = request.getParameter("nume_caracteristica");
            String unitate = request.getParameter("unitate_masura");

            if (numeC != null && unitate != null) {
                try {
                    jb.connect();
                    jb.adaugaCaracteristica(numeC, unitate);
                    jb.disconnect();
        %>
                <div class="alert alert-success text-center shadow-sm">
                    <h1>Caracteristică salvată!</h1>
                    <p>Tipul de măsurătoare <strong><%= numeC %></strong> a fost adăugat.</p>
                    <a href="tabela_Caracteristici.jsp" class="btn btn-custom mt-3">Vezi Lista</a>
                    <a href="nou_Caracteristica.jsp" class="btn btn-outline-secondary mt-3">Adaugă alta</a>
                </div>
        <%
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger'>Eroare: " + e.getMessage() + "</div>");
                }
            } else {
        %>
            <h1 class="text-center mb-4">Definire Caracteristică Nouă</h1>
            <div class="card shadow-sm mx-auto" style="max-width: 500px;">
                <div class="card-body">
                    <form action="nou_Caracteristica.jsp" method="post">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nume Caracteristică:</label>
                            <input type="text" name="nume_caracteristica" class="form-control" placeholder="ex: Puls" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Unitate de Măsură:</label>
                            <input type="text" name="unitate_masura" class="form-control" placeholder="ex: bpm sau kg" required>
                        </div>
                        <button type="submit" class="btn btn-custom w-100">Salvează în Nomenclator</button>
                    </form>
                </div>
            </div>
        <% } %>
    </div>
</body>
</html>