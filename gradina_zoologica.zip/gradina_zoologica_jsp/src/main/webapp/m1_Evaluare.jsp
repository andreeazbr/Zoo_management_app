<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,db.*,java.sql.*"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Modifică Evaluare Medicală</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .nav-custom { background-color: #36486b !important; }
        .btn-custom { background-color: #36486b; color: white; }
    </style>
</head>
<jsp:useBean id="jb" scope="session" class="db.JavaBean" />
<body>
    <nav class="navbar navbar-dark nav-custom px-3">
        <a class="navbar-brand" href="index.jsp">Zoo Admin - Editare Evaluare</a>
    </nav>

    <div class="container mt-5">
        <%
            try {
                String pk = request.getParameter("primarykey");
                if (pk != null) {
                    int idEval = Integer.parseInt(pk);
                    jb.connect();
                 
                    ResultSet rs = jb.intoarceLinieDupaId("evaluari_caracteristici", "id_evaluare", idEval);
                    
                    if (rs.next()) {
                        int idAnimalCurent = rs.getInt("id_animal");
                        int idCaracCurenta = rs.getInt("id_caracteristica");
                        String valoare = rs.getString("valoare_masurata");
                        String data = rs.getString("data_evaluare");
                        String obs = rs.getString("observatii");

                        ResultSet rsA = jb.vedeTabela("animale");
                        ResultSet rsC = jb.vedeTabela("caracteristici");
        %>
            <div class="card shadow mx-auto" style="max-width: 700px;">
                <div class="card-header bg-dark text-white">Modificare Înregistrare Jurnal #<%= idEval %></div>
                <div class="card-body">
                    <form action="m2_Evaluare.jsp" method="post">
                        <input type="hidden" name="id_evaluare" value="<%= idEval %>">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Animal:</label>
                            <select name="id_animal" class="form-select">
                                <% while(rsA.next()){ %>
                                    <option value="<%= rsA.getInt("id_animal") %>" <%= (rsA.getInt("id_animal") == idAnimalCurent ? "selected" : "") %>>
                                        <%= rsA.getString("nume") %> (<%= rsA.getString("specie") %>)
                                    </option>
                                <% } %>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Caracteristică:</label>
                            <select name="id_caracteristica" class="select form-select">
                                <% while(rsC.next()){ %>
                                    <option value="<%= rsC.getInt("id_caracteristica") %>" <%= (rsC.getInt("id_caracteristica") == idCaracCurenta ? "selected" : "") %>>
                                        <%= rsC.getString("nume_caracteristica") %>
                                    </option>
                                <% } %>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Valoare:</label>
                                <input type="text" name="valoare_masurata" class="form-control" value="<%= valoare %>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Data:</label>
                                <input type="date" name="data_evaluare" class="form-control" value="<%= data %>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Observații:</label>
                            <textarea name="observatii" class="form-control" rows="3"><%= (obs != null ? obs : "") %></textarea>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-custom px-5">Salvează Modificările</button>
                            <a href="tabela_Evaluari.jsp" class="btn btn-outline-secondary">Anulează</a>
                        </div>
                    </form>
                </div>
            </div>
        <%
                        rsA.close(); rsC.close();
                    }
                    rs.close();
                    jb.disconnect();
                }
            } catch (Exception e) {
                out.println("<div class='alert alert-danger'>Eroare: " + e.getMessage() + "</div>");
            }
        %>
    </div>
</body>
</html>