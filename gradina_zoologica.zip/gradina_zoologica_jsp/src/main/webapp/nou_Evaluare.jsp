<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,db.*,java.sql.*"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Înregistrare Evaluare Nouă</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .nav-custom { background-color: #36486b !important; }
        .btn-custom { background-color: #36486b; color: white; }
    </style>
</head>
<jsp:useBean id="jb" scope="session" class="db.JavaBean" />
<body>
    <nav class="navbar navbar-dark nav-custom px-3">
        <a class="navbar-brand" href="index.jsp">Zoo Admin</a>
    </nav>

    <div class="container mt-5">
        <%
            String idA = request.getParameter("id_animal");
            String idC = request.getParameter("id_caracteristica");
            String valoare = request.getParameter("valoare_masurata");
            String data = request.getParameter("data_evaluare");
            String obs = request.getParameter("observatii");

            if (idA != null && idC != null && valoare != null) {
                try {
                    jb.connect();
                    jb.adaugaEvaluare(Integer.parseInt(idA), Integer.parseInt(idC), valoare, data, obs);
                    jb.disconnect();
        %>
                <div class="alert alert-success text-center shadow-sm">
                    <h1>Evaluare Înregistrată!</h1>
                    <p>Datele au fost salvate cu succes în jurnalul medical.</p>
                    <a href="tabela_Evaluari.jsp" class="btn btn-custom mt-3">Vezi Jurnal</a>
                    <a href="nou_Evaluare.jsp" class="btn btn-outline-secondary mt-3">Adaugă alta</a>
                </div>
        <%
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger'>Eroare la salvare: " + e.getMessage() + "</div>");
                }
            } else {
                jb.connect();
                ResultSet rsA = jb.vedeTabela("animale");
                ResultSet rsC = jb.vedeTabela("caracteristici");
        %>
            <h1 class="text-center mb-4">Înregistrare Date Medicale</h1>
            <div class="card shadow-sm mx-auto" style="max-width: 600px;">
                <div class="card-body">
                    <form action="nou_Evaluare.jsp" method="post">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Selectează Animalul:</label>
                            <select name="id_animal" class="form-select" required>
                                <% while(rsA.next()){ %>
                                    <option value="<%= rsA.getInt("id_animal") %>">
                                        <%= rsA.getString("nume") %> (<%= rsA.getString("specie") %>)
                                    </option>
                                <% } %>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Selectează Caracteristica:</label>
                            <select name="id_caracteristica" class="form-select" required>
                                <% while(rsC.next()){ %>
                                    <option value="<%= rsC.getInt("id_caracteristica") %>">
                                        <%= rsC.getString("nume_caracteristica") %> [<%= rsC.getString("unitate_masura") %>]
                                    </option>
                                <% } %>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Valoare Măsurată:</label>
                                <input type="text" name="valoare_masurata" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Data Evaluării:</label>
                                <input type="date" name="data_evaluare" class="form-control" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Observații:</label>
                            <textarea name="observatii" class="form-control" rows="2"></textarea>
                        </div>

                        <button type="submit" class="btn btn-custom w-100 btn-lg">Salvează Evaluarea</button>
                    </form>
                </div>
            </div>
        <% 
                rsA.close(); rsC.close(); jb.disconnect();
            } 
        %>
    </div>
</body>
</html>