<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Zoo Admin | Panou Control</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .hero-section { 
            background: linear-gradient(rgba(54, 72, 107, 0.8), rgba(54, 72, 107, 0.8)), 
                        url('https://images.unsplash.com/photo-1534567153574-2b12153a87f0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            margin-bottom: 50px;
        }
        .card-custom {
            border: none;
            border-radius: 15px;
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
            height: 100%;
        }
        .card-custom:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        .icon-box {
            font-size: 3rem;
            margin-bottom: 20px;
            color: #36486b;
        }
        .btn-zoo { background-color: #36486b; color: white; border-radius: 25px; padding: 10px 25px; }
        .btn-zoo:hover { background-color: #2a3854; color: white; }
    </style>
</head>
<body>

    <header class="hero-section text-center">
        <div class="container">T
            <h1 class="display-3 fw-bold">Zoo Management System</h1>
            <p class="lead">Monitorizarea eficientă a stării de sănătate a animalelor</p>
        </div>
    </header>

    <div class="container mb-5">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card card-custom shadow-sm text-center p-4">
                    <div class="card-body">
                        <div class="icon-box">🐾</div>
                        <h3 class="card-title h4 fw-bold">Animale</h3>
                        <p class="text-muted">Gestionați lista completă a locatarilor grădinii zoologice, adăugați specii noi sau actualizați profile.</p>
                        <div class="d-grid gap-2 mt-4">
                            <a href="tabela_Animale.jsp" class="btn btn-zoo">Vezi Animale</a>
                            <a href="nou_Animal.jsp" class="btn btn-outline-secondary btn-sm">Adaugă Animal</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-custom shadow-sm text-center p-4">
                    <div class="card-body">
                        <div class="icon-box">📊</div>
                        <h3 class="card-title h4 fw-bold">Caracteristici</h3>
                        <p class="text-muted">Definiți tipurile de măsurători medicale și unitățile de măsură folosite în evaluări.</p>
                        <div class="d-grid gap-2 mt-4">
                            <a href="tabela_Caracteristici.jsp" class="btn btn-zoo">Nomenclator</a>
                            <a href="nou_Caracteristica.jsp" class="btn btn-outline-secondary btn-sm">Tip Nou</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-custom shadow-sm text-center p-4">
                    <div class="card-body">
                        <div class="icon-box">🏥</div>
                        <h3 class="card-title h4 fw-bold">Jurnal Medical</h3>
                        <p class="text-muted">Înregistrați și monitorizați evaluările periodice pentru fiecare animal în parte.</p>
                        <div class="d-grid gap-2 mt-4">
                            <a href="tabela_Evaluari.jsp" class="btn btn-zoo">Vezi Jurnal</a>
                            <a href="nou_Evaluare.jsp" class="btn btn-outline-secondary btn-sm">Evaluare Nouă</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center py-4 text-muted border-top bg-white">
        <p>&copy; 2026 Gradina Zoologica Admin - Proiect Gestiune Baze de Date</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>