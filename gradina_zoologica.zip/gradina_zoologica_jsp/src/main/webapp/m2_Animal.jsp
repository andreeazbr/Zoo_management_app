<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Confirmare Modificare Animal</title>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
            .btn-custom:hover { background-color: #2a3854; color: white; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
            </div>
        </nav>

        <div class="container mt-5 text-center">
            <%
                try {
                    jb.connect();
                    
                    int id_animal = Integer.parseInt(request.getParameter("id_animal"));
                    String nume = request.getParameter("nume");
                    String specie = request.getParameter("specie");
                    String varsta = request.getParameter("varsta");
                    String data = request.getParameter("data_inregistrare");
                    
                    String[] campuri = {"nume", "specie", "varsta", "data_inregistrare"};
                    String[] valori = {nume, specie, varsta, data};
                    
                    jb.modificaTabela("animale", "id_animal", id_animal, campuri, valori);
                    jb.disconnect();
            %>
            
            <div class="alert alert-success shadow-sm p-4">
                <h1 class="alert-heading">Modificare Reușită!</h1>
                <p class="lead">Datele pentru animalul <strong><%= nume %></strong> au fost actualizate cu succes în baza de date.</p>
                <hr>
                <div class="mt-4">
                    <a href="tabela_Animale.jsp" class="btn btn-custom btn-lg px-4 me-2">Înapoi la Inventar</a>
                    <a href="index.jsp" class="btn btn-outline-secondary btn-lg px-4">Acasă</a>
                </div>
            </div>

            <%
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger shadow-sm p-4'>");
                    out.println("<h2>Eroare la procesare!</h2>");
                    out.println("<p>Modificările nu au putut fi salvate.</p>");
                    out.println("<hr><p class='small'>" + e.getMessage() + "</p>");
                    out.println("<a href='tabela_Animale.jsp' class='btn btn-danger mt-3'>Înapoi la Tabelă</a></div>");
                }
            %>
        </div>
    </body>
</html>