<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Adaugă Animal Nou</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
            .btn-custom:hover { background-color: #2a3854; color: white; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="tabela_Animale.jsp" style="color:white;">Înapoi la Inventar</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container mt-5">
            <%
                String nume = request.getParameter("nume");
                String specie = request.getParameter("specie");
                String varstaStr = request.getParameter("varsta");
                String data = request.getParameter("data_inregistrare");

                // Verificăm dacă formularul a fost trimis
                if (nume != null && specie != null && varstaStr != null) {
                    try {
                        jb.connect();
                        int varsta = Integer.parseInt(varstaStr);
                        
                        // Apelăm metoda de adăugare din JavaBean (trebuie să existe în db.JavaBean)
                        jb.adaugaAnimal(nume, specie, varsta, data);
                        jb.disconnect();
            %>
                        <div class="alert alert-success text-center shadow-sm p-4">
                            <h1>Animal adăugat cu succes!</h1>
                            <p><strong><%= nume %></strong> (<%= specie %>) face acum parte din inventarul grădinii zoologice.</p>
                            <div class="mt-4">
                                <a href="tabela_Animale.jsp" class="btn btn-custom px-4 me-2">Vezi Inventar</a>
                                <a href="nou_Animal.jsp" class="btn btn-outline-secondary px-4">Adaugă alt animal</a>
                            </div>
                        </div>
            <%
                    } catch (Exception e) {
                        out.println("<div class='alert alert-danger text-center'>Eroare la salvare: " + e.getMessage() + "</div>");
                    }
                } else {
            %>
                <h1 class="text-center mb-4">Înregistrare Animal Nou</h1>
                <div class="card shadow-sm mx-auto" style="max-width: 600px;">
                    <div class="card-body p-4">
                        <form action="nou_Animal.jsp" method="post">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nume Animal:</label>
                                <input type="text" name="nume" class="form-control" placeholder="ex: Simba" required />
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Specie:</label>
                                <input type="text" name="specie" class="form-control" placeholder="ex: Leu" required />
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Vârstă:</label>
                                <input type="number" name="varsta" class="form-control" placeholder="Ani" required />
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Data Înregistrare:</label>
                                <input type="date" name="data_inregistrare" class="form-control" required />
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-custom btn-lg w-100">Adaugă în Baza de Date</button>
                            </div>
                        </form>
                    </div>
                </div>
            <%
                }
            %>
        </div>
    </body>
</html>