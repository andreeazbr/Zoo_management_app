<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Administrare Animale</title>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
            .btn-custom:hover { background-color: #2a3854; color: white; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    <jsp:setProperty name="jb" property="*" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navAnimale" role="button" data-bs-toggle="dropdown" style="color:white;">Animale</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Animale.jsp">Vizualizează Inventar</a></li> 
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Animal.jsp">Editează Date</a></li>
                            </ul>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navCarac" role="button" data-bs-toggle="dropdown" style="color:white;">Caracteristici</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Caracteristici.jsp">Vizualizează Tipuri</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Caracteristica.jsp">Editează Tipuri</a></li>
                            </ul>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navEval" role="button" data-bs-toggle="dropdown" style="color:white;">Evaluări Medicale</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Evaluari.jsp">Jurnal Evaluări</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Evaluare.jsp">Editează Jurnal</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
        
        <div class="container mt-4">
            <h1 class="text-center">Modificare Date Animale</h1>
            <p class="text-center text-muted">Selectați animalul pe care doriți să îl editați.</p>
            <br/>
           
            <form action="m1_Animal.jsp" method="post">
                <table class="table table-bordered table-hover text-center shadow-sm">
                    <thead class="table-dark">
                        <tr>
                            <th>Selectează</th>
                            <th>ID Animal</th>
                            <th>Nume</th>
                            <th>Specie</th>
                            <th>Vârstă (ani)</th>
                            <th>Data Înregistrare</th>
                        </tr>
                    </thead>
                    <tbody>
                    <%
                        try {
                            jb.connect();
                            ResultSet rs = jb.vedeTabela("animale");
                            while (rs.next()) {
                                long x = rs.getLong("id_animal");
                    %>
                        <tr>
                            <td><input type="radio" name="primarykey" value="<%= x %>" required /></td>
                            <td><%= x %></td>
                            <td><strong><%= rs.getString("nume") %></strong></td>
                            <td><%= rs.getString("specie") %></td>
                            <td><%= rs.getInt("varsta") %></td>
                            <td><%= rs.getDate("data_inregistrare") %></td>
                        </tr>
                    <%
                            }
                            rs.close();
                        } catch (Exception e) {
                            out.print("<tr><td colspan='6' class='text-danger'>Eroare: " + e.getMessage() + "</td></tr>");
                        } finally {
                            jb.disconnect();
                        }
                    %>
                    </tbody>
                </table>
                
                <div class="text-center mt-4 mb-5">
                    <button type="submit" class="btn btn-custom px-4">Modifică Animalul Selectat</button>
                    <a href="nou_Animal.jsp" class="btn btn-outline-dark px-4 ms-2">Adaugă un Animal Nou</a>
                </div>
            </form>
        </div>
    </body>
</html>