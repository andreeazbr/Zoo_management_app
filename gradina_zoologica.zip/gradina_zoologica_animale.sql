-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: gradina_zoologica
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `animale`
--

DROP TABLE IF EXISTS `animale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `animale` (
  `id_animal` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nume` varchar(45) NOT NULL,
  `specie` varchar(45) NOT NULL,
  `varsta` int unsigned NOT NULL,
  `data_inregistrare` date NOT NULL,
  PRIMARY KEY (`id_animal`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `animale`
--

LOCK TABLES `animale` WRITE;
/*!40000 ALTER TABLE `animale` DISABLE KEYS */;
INSERT INTO `animale` VALUES (1,'Simba','Leu',5,'2023-01-15'),(2,'Baloo','Urs Brun',8,'2023-02-20'),(3,'Rico','Pinguin',3,'2023-05-10'),(4,'Zelda','Zebra',4,'2023-06-01'),(5,'Kaa','Piton',10,'2023-03-12'),(6,'Dumbo','Elefant',12,'2022-11-30'),(10,'Winnie','Urs',5,'2026-01-12'),(11,'Bagheera','Pantera',7,'2023-08-12'),(12,'Shifu','Panda Rosu',15,'2021-12-05'),(13,'Akela','Lup',9,'2023-11-20'),(14,'Sid','Lenes',20,'2020-05-15'),(15,'Horton','Elefant',25,'2019-10-10'),(16,'Black','Urs',3,'2026-01-12'),(17,'White','Urs',7,'2026-01-12'),(18,'Zio','Zebra',6,'2026-01-12'),(19,'Arnold','Arici',1,'2024-02-29'),(20,'Enrico','Pinguin',5,'2026-01-11');
/*!40000 ALTER TABLE `animale` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 21:55:53
