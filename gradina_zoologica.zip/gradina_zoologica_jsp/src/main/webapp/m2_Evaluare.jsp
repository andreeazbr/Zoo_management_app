<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,db.*,java.sql.*"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Confirmare Modificare</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<jsp:useBean id="jb" scope="session" class="db.JavaBean" />
<body>
    <div class="container mt-5 text-center">
        <%
            try {
                int idEval = Integer.parseInt(request.getParameter("id_evaluare"));
                String idA = request.getParameter("id_animal");
                String idC = request.getParameter("id_caracteristica");
                String val = request.getParameter("valoare_masurata");
                String data = request.getParameter("data_evaluare");
                String obs = request.getParameter("observatii");

                jb.connect();
                
                String[] campuri = {"id_animal", "id_caracteristica", "valoare_masurata", "data_evaluare", "observatii"};
                String[] valori = {idA, idC, val, data, obs};
                
                // Folosim metoda generica din JavaBean
                jb.modificaTabela("evaluari_caracteristici", "id_evaluare", idEval, campuri, valori);
                jb.disconnect();
        %>
            <div class="alert alert-success shadow-sm p-5">
                <h1 class="display-5">Actualizare Reușită!</h1>
                <p class="lead">Înregistrarea din jurnalul medical a fost modificată cu succes.</p>
                <hr>
                <a href="tabela_Evaluari.jsp" class="btn btn-primary btn-lg" style="background-color:#36486b;">Înapoi la Jurnal</a>
            </div>
        <%
            } catch (Exception e) {
                out.println("<div class='alert alert-danger p-4 shadow-sm'>");
                out.println("<h2>Eroare la procesare</h2>");
                out.println("<p>" + e.getMessage() + "</p>");
                out.println("<a href='tabela_Evaluari.jsp' class='btn btn-danger mt-3'>Înapoi</a></div>");
            }
        %>
    </div>
</body>
</html>