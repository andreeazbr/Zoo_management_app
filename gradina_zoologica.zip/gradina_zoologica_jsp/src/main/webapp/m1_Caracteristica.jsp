<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html lang="ro">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Modifică Caracteristică</title>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
            .btn-custom:hover { background-color: #2a3854; color: white; }
            .form-container { max-width: 600px; margin: auto; padding: 20px; border: 1px solid #dee2e6; border-radius: 8px; background-color: #f8f9fa; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    <jsp:setProperty name="jb" property="*" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
                <div class="collapse navbar-collapse" id="navRes">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navAnimale" role="button" data-bs-toggle="dropdown" style="color:white;">Animale</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Animale.jsp">Vizualizează</a></li> 
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Animal.jsp">Editează</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navCarac" role="button" data-bs-toggle="dropdown" style="color:white;">Caracteristici</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Caracteristici.jsp">Vizualizează</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Caracteristica.jsp">Editează</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container mt-5">
            <h1 class="text-center">Modifică Tip Caracteristică</h1>
            <p class="text-center text-muted">Actualizați definiția măsurătorii în nomenclator.</p>
            <br/>
           
            <%
                String numeC = "", unitate = "";
                int aux = 0;
                try {
                    String pk = request.getParameter("primarykey");
                    if (pk != null) {
                        aux = Integer.parseInt(pk);
                        jb.connect();
                        ResultSet rs = jb.intoarceLinieDupaId("caracteristici", "id_caracteristica", aux);
                        if (rs.next()) {
                            numeC = rs.getString("nume_caracteristica");
                            unitate = rs.getString("unitate_masura");
                        }
                        rs.close();
                        jb.disconnect();
                    }
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger'>Eroare la preluarea datelor: " + e.getMessage() + "</div>");
                }
            %>

            <div class="form-container shadow-sm">
                <form action="m2_Caracteristica.jsp" method="post">
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label text-end"><strong>ID Caracteristică:</strong></label>
                        <div class="col-sm-8">
                            <input type="text" name="id_caracteristica" class="form-control bg-light" value="<%= aux %>" readonly>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label text-end"><strong>Denumire:</strong></label>
                        <div class="col-sm-8">
                            <input type="text" name="nume_caracteristica" class="form-control" value="<%= numeC %>" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-4 col-form-label text-end"><strong>Unitate Măsură:</strong></label>
                        <div class="col-sm-8">
                            <input type="text" name="unitate_masura" class="form-control" value="<%= unitate %>" required>
                        </div>
                    </div>
                    <div class="text-center mt-4">
                        <input type="submit" class="btn btn-custom px-5" value="Salvează Modificările">
                        <a href="tabela_Caracteristici.jsp" class="btn btn-outline-secondary ms-2">Anulează</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>