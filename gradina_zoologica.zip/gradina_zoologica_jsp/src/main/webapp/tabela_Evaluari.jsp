<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Jurnal Evaluări Medicale</title>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
            .btn-custom:hover { background-color: #2a3854; color: white; }
            .table-container { overflow-x: auto; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    <jsp:setProperty name="jb" property="*" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navAnimale" role="button" data-bs-toggle="dropdown" style="color:white;">Animale</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Animale.jsp">Vizualizează Inventar</a></li> 
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Animal.jsp">Editează Date</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navCaracteristici" role="button" data-bs-toggle="dropdown" style="color:white;">Caracteristici</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="tabela_Caracteristici.jsp">Vizualizează Tipuri</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="modifica_Caracteristica.jsp">Editează Tipuri</a></li>
                            </ul>
                        </li>
               			<li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navEvaluari" role="button" data-bs-toggle="dropdown" style="color:white;">
                        Evaluări Medicale
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="tabela_Evaluari.jsp">Jurnal Evaluări</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="modifica_Evaluare.jsp">Editează Jurnal</a></li>
                    </ul>
                </li>
                    </ul>
                </div>
            </div>
        </nav>
        
        <div class="container-fluid px-4 mt-4">
            <h1 class="text-center">Jurnal Evaluări Caracteristici</h1>
            <p class="text-center text-muted small">Evidența măsurătorilor pentru animalele din grădina zoologică.</p>
            <br/>
            
            <form action="sterge_Evaluare.jsp" method="post">
                <div class="table-container shadow-sm">
                    <table class="table table-bordered table-striped align-middle text-center">
                        <thead class="table-dark">
                            <tr>
                                <th>Mark</th>
                                <th>ID Evaluare</th>
                                <th>Animal (Specie)</th>
                                <th>Caracteristică</th>
                                <th>Valoare Măsurată</th>
                                <th>Unitate</th>
                                <th>Data Evaluării</th>
                                <th>Observații</th>
                            </tr>
                        </thead>
                        <tbody>
                        <%
                            try {
                                jb.connect();
                                ResultSet rs = jb.vedeEvaluari();
                                while (rs.next()) {
                                    long x = rs.getLong("id_evaluare");
                        %>
                            <tr>
                                <td><input type="checkbox" name="primarykey" value="<%= x %>" /></td>
                                <td><%= x %></td>
                                <td><strong><%= rs.getString("nume") %></strong> (<%= rs.getString("specie") %>)</td>
                                <td><%= rs.getString("nume_caracteristica") %></td>
                                <td class="text-primary fw-bold"><%= rs.getString("valoare_masurata") %></td>
                                <td><%= rs.getString("unitate_masura") %></td>
                                <td><%= rs.getDate("data_evaluare") %></td>
                                <td class="text-start"><small><%= rs.getString("observatii") != null ? rs.getString("observatii") : "-" %></small></td>
                            </tr>
                        <%
                                }
                                rs.close();
                            } catch (Exception e) {
                                out.print("<tr><td colspan='8' class='text-danger'>Eroare: " + e.getMessage() + "</td></tr>");
                            } finally {
                                jb.disconnect();
                            }
                        %>
                        </tbody>
                    </table>
                </div>
                
                <div class="text-center mt-4 mb-5">
                    <button type="submit" class="btn btn-danger px-4 me-2">Șterge măsurătorile marcate</button>
                    <a href="nou_Evaluare.jsp" class="btn btn-custom px-4">Adaugă evaluare nouă</a>
                </div>
            </form>
        </div>
    </body>
</html>