<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
        <title>Modifică Date Animal</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
        
        <style>
            .nav-custom { background-color: #36486b !important; }
            .btn-custom { background-color: #36486b; border-color: #36486b; color: white; }
            .btn-custom:hover { background-color: #2a3854; color: white; }
        </style>
    </head>
    
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    
    <body>
        <nav class="navbar navbar-expand-lg navbar-light nav-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.jsp" style="color:white;">Zoo Admin</a>
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="tabela_Animale.jsp" style="color:white;">Înapoi la Inventar</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container mt-5">
            <h1 class="text-center mb-4">Editare Profil Animal</h1>
            
            <%
                try {
                    jb.connect();
                    String pkParam = request.getParameter("primarykey");
                    
                    if (pkParam != null) {
                        int idAnimal = Integer.parseInt(pkParam);
						ResultSet rs = jb.intoarceLinieDupaId("animale", "id_animal", idAnimal);
                        
                        if (rs.next()) {
                            String nume = rs.getString("nume");
                            String specie = rs.getString("specie");
                            int varsta = rs.getInt("varsta");
                            String data = rs.getString("data_inregistrare");
            %>
            
            <div class="card shadow-sm mx-auto" style="max-width: 600px;">
                <div class="card-body">
                    <form action="m2_Animal.jsp" method="post">
                        <div class="mb-3">
                            <label class="form-label fw-bold">ID Animal (needitabil):</label>
                            <input type="text" name="id_animal" class="form-control bg-light" value="<%= idAnimal %>" readonly/>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nume Animal:</label>
                            <input type="text" name="nume" class="form-control" value="<%= nume %>" required/>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Specie:</label>
                            <input type="text" name="specie" class="form-control" value="<%= specie %>" required/>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Vârstă (ani):</label>
                            <input type="number" name="varsta" class="form-control" value="<%= varsta %>" required/>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Data Înregistrare:</label>
                            <input type="date" name="data_inregistrare" class="form-control" value="<%= data %>" required/>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-custom btn-lg px-5">Salvează Modificările</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <%
                        } else {
                            out.println("<div class='alert alert-danger'>Animalul nu a fost găsit în baza de date.</div>");
                        }
                        rs.close();
                    } else {
                        out.println("<div class='alert alert-warning text-center'>Vă rugăm selectați un animal din tabelă pentru a-l edita.</div>");
                    }
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger text-center'>Eroare: " + e.getMessage() + "</div>");
                } finally {
                    jb.disconnect();
                }
            %>
        </div>
    </body>
</html>