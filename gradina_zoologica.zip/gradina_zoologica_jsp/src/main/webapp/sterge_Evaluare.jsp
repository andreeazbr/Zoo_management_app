<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page language="java" import="java.lang.*,java.math.*,db.*,java.sql.*, java.io.*, java.util.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Status Ștergere Evaluare</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <jsp:useBean id="jb" scope="session" class="db.JavaBean" />
    <body>
        <div class="container mt-5 text-center">
        <%
            String[] selectate = request.getParameterValues("primarykey");
            if (selectate != null) {
                try {
                    jb.connect();
                    // Tabela de legatura: evaluari_caracteristici
                    jb.stergeDateTabela(selectate, "evaluari_caracteristici", "id_evaluare");
                    jb.disconnect();
        %>
            <div class="alert alert-success p-5 shadow-sm">
                <h1>Evaluări șterse!</h1>
                <p>Jurnalul de măsurători a fost actualizat cu succes.</p>
                <a href="tabela_Evaluari.jsp" class="btn btn-primary mt-3" style="background-color: #36486b;">Înapoi la Jurnal</a>
            </div>
        <%
                } catch (Exception e) {
                    out.println("<div class='alert alert-danger'>Eroare la ștergere: " + e.getMessage() + "</div>");
                }
            } else {
        %>
            <div class="alert alert-warning">
                <p>Nu ați selectat nicio evaluare pentru ștergere.</p>
                <a href="tabela_Evaluari.jsp" class="btn btn-warning">Înapoi</a>
            </div>
        <%
            }
        %>
        </div>
    </body>
</html>