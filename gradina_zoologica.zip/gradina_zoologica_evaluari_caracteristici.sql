-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: gradina_zoologica
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `evaluari_caracteristici`
--

DROP TABLE IF EXISTS `evaluari_caracteristici`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluari_caracteristici` (
  `id_evaluare` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_animal` bigint unsigned NOT NULL,
  `id_caracteristica` bigint unsigned NOT NULL,
  `valoare_masurata` varchar(45) NOT NULL,
  `data_evaluare` date NOT NULL,
  `observatii` text,
  PRIMARY KEY (`id_evaluare`),
  KEY `fk_animal` (`id_animal`),
  KEY `fk_caracteristica` (`id_caracteristica`),
  CONSTRAINT `fk_animal` FOREIGN KEY (`id_animal`) REFERENCES `animale` (`id_animal`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_caracteristica` FOREIGN KEY (`id_caracteristica`) REFERENCES `caracteristici` (`id_caracteristica`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluari_caracteristici`
--

LOCK TABLES `evaluari_caracteristici` WRITE;
/*!40000 ALTER TABLE `evaluari_caracteristici` DISABLE KEYS */;
INSERT INTO `evaluari_caracteristici` VALUES (1,1,1,'190','2023-10-01','Greutate optima'),(2,1,2,'8','2023-10-03','Comportament teritorial'),(3,2,1,'350','2023-11-15','Pregatire hibernare'),(4,2,3,'Buna','2023-11-17','Blana deasa, sanatoasa'),(5,3,3,'Excelenta','2023-12-20','Foarte activ'),(6,4,4,'12','2023-12-21','Dieta bazata pe fan'),(7,5,5,'4.5','2024-01-05','Masuratoare dupa naparlire'),(8,5,6,'26','2024-01-06','Sange rece, temperatura ambientala'),(9,6,1,'4500','2024-01-10','Adult sanatos'),(10,6,4,'150','2024-01-20','Consum mare de vegetatie'),(12,1,1,'195','2023-11-05','Crestere stabila'),(13,1,1,'202','2024-01-10','Apetit marit'),(14,1,1,'198','2024-03-15','Control de rutina'),(15,2,1,'355','2023-12-20','Monitorizare iarna'),(16,2,1,'340','2024-02-15','Sfarsit hibernare'),(17,2,1,'365','2024-05-20','Revenire la greutate normala'),(22,10,1,'120','2026-01-10','Greutate normala pentru pui'),(23,10,3,'Buna','2026-01-10','Foarte jucaus'),(24,11,1,'65','2024-01-15','Greutate ideala'),(25,11,2,'4','2024-01-15','Calm in timpul examinarii'),(26,15,1,'4800','2025-10-01','Masuratoare de rutina'),(27,15,1,'4850','2025-11-15','Crestere usoara'),(28,15,1,'4900','2026-01-05','Stare excelenta'),(29,12,4,'1.5','2024-02-20','Consum optim de bambus'),(30,13,3,'Excelenta','2024-03-01','Lider de haita viguros'),(31,13,5,'1.2','2024-03-01','Inaltime la umar'),(32,14,6,'32','2024-03-10','Temperatura scazuta, normal'),(33,14,4,'0.5','2024-03-10','Apetit scazut, specific speciei'),(34,1,4,'2','2026-01-12','Animalul se hrănește corespunzător perioadei și vârstei sale.'),(35,14,7,'110','2025-11-12','Puls ușor crescut.');
/*!40000 ALTER TABLE `evaluari_caracteristici` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 21:55:52
